# Down-Town-Drift---Endless-Runner-Game
---
# This game is an endless runner.
---
# You control a car and can move it up or down to avoid obstacles
---
# There are power-ups and coins you can collect along the way
---
# You can customise your car for free and for coins in the Avatar
---
# There is a tutorial explaining the power-ups, controls, and aim of the game.
---
# Anyway, have fun!
